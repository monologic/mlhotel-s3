@extends('home.index')

@section('title', 'Finalizando Reservacion - Residencial Moquegua')

@section('content')
	<div class="general">
		<div style="top:0;width: 100%;margin-top: 10%;margin-bottom:10%">
			<p class="block-center" align="center" style="font-size: 30px"> Gracias por su preferencia, lo esperamos. </p>
		</div>
	</div>
@endsection