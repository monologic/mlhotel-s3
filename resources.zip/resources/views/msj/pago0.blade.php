@extends('home.index')

@section('title', 'Pago en destino - Residencial Moquegua')

@section('content')
	<div class="general">
		<div style="top:0;width: 100%;margin-top: 10%;margin-bottom:10%">
			<p class="block-center" align="center" style="font-size: 30px"> Gracias por su preferencia</p>
		</div>
	</div>
@endsection