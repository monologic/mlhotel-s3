<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title></title>
	<link rel="stylesheet" href="">
</head>
<body >
<br>
<br>
<p>Asunto: {{ $subject }}</p>
<br>
<p>Email: {{ $email }}</p>
<br>
<br>
<p>{{ $body }}</p>
	
</body>
</html>